const municipalityData = [
    { id: 1, name: "Central Municipal Corporation", lat: 28.6139, lng: 77.2090, email: "central@municipality.gov", phone: "+91-11-2345-6789" },
    { id: 2, name: "North Zone Municipality", lat: 28.7041, lng: 77.1025, email: "north@municipality.gov", phone: "+91-11-2345-6790" },
    { id: 3, name: "South Zone Municipality", lat: 28.5245, lng: 77.1855, email: "south@municipality.gov", phone: "+91-11-2345-6791" },
    { id: 4, name: "East Zone Municipality", lat: 28.6280, lng: 77.2972, email: "east@municipality.gov", phone: "+91-11-2345-6792" },
    { id: 5, name: "West Zone Municipality", lat: 28.6519, lng: 77.0581, email: "west@municipality.gov", phone: "+91-11-2345-6793" },
    { id: 6, name: "New Delhi Municipal Council", lat: 28.6129, lng: 77.2295, email: "ndmc@municipality.gov", phone: "+91-11-2345-6794" }
];

const wasteTypes = ["Plastic", "Organic", "Metal", "Paper", "E-Waste", "Glass", "Mixed Debris"];

let map, userMarker, routeLine, currentPosition = null;
let tileLayers = {};
let selectedCategory = null;
let selectedMunicipality = null;

document.addEventListener('DOMContentLoaded', function() {
    initMap();
    initGeolocation();
    initTabs();
    initThemeToggle();
    initUploadZones();
    initCategoryButtons();
    initChatbot();
    initDashboard();
    initEventListeners();
});

function initMap() {
    map = L.map('map', {
        center: [28.6139, 77.2090],
        zoom: 12,
        zoomControl: true
    });

    tileLayers.dark = L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; OpenStreetMap, &copy; CARTO',
        maxZoom: 19
    });

    tileLayers.light = L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; OpenStreetMap, &copy; CARTO',
        maxZoom: 19
    });

    tileLayers.satellite = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: '&copy; Esri',
        maxZoom: 19
    });

    tileLayers.dark.addTo(map);

    map.on('click', handleMapClick);

    document.querySelectorAll('.layer-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const layer = this.dataset.layer;
            switchMapLayer(layer);
            document.querySelectorAll('.layer-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

function switchMapLayer(layerName) {
    Object.values(tileLayers).forEach(layer => map.removeLayer(layer));
    tileLayers[layerName].addTo(map);
}

function initGeolocation() {
    if ('geolocation' in navigator) {
        navigator.geolocation.getCurrentPosition(
            handlePositionSuccess,
            handlePositionError,
            { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
        );
    } else {
        showManualMarkerHint();
        showToast('error', 'Geolocation Unavailable', 'Please click on the map to set your location.');
    }
}

function handlePositionSuccess(position) {
    const { latitude, longitude, accuracy } = position.coords;
    currentPosition = { lat: latitude, lng: longitude };
    
    document.getElementById('locatingIndicator').classList.add('hidden');
    document.getElementById('locationDetails').classList.remove('hidden');
    
    document.getElementById('latitude').textContent = latitude.toFixed(6);
    document.getElementById('longitude').textContent = longitude.toFixed(6);
    document.getElementById('accuracy').textContent = `${accuracy.toFixed(1)}m`;
    
    reverseGeocode(latitude, longitude);
    
    if (userMarker) {
        map.removeLayer(userMarker);
    }
    
    userMarker = L.marker([latitude, longitude], {
        icon: createPulsingIcon()
    }).addTo(map);
    
    map.setView([latitude, longitude], 15);
    
    updateMunicipalityList();
}

function handlePositionError(error) {
    console.error('Geolocation error:', error);
    showManualMarkerHint();
    
    let message = 'Unable to get your location.';
    if (error.code === 1) message = 'Location permission denied.';
    else if (error.code === 2) message = 'Location unavailable.';
    else if (error.code === 3) message = 'Location request timed out.';
    
    showToast('warning', 'Location Error', message + ' Click on the map to set location manually.');
    
    document.getElementById('locatingIndicator').innerHTML = `
        <p style="color: var(--accent-orange);">Could not detect location</p>
        <p style="font-size: 0.85rem; color: var(--text-secondary);">Click on map to set manually</p>
    `;
}

function showManualMarkerHint() {
    document.getElementById('manualHint').classList.add('visible');
}

function handleMapClick(e) {
    const { lat, lng } = e.latlng;
    currentPosition = { lat, lng };
    
    document.getElementById('locatingIndicator').classList.add('hidden');
    document.getElementById('locationDetails').classList.remove('hidden');
    document.getElementById('manualHint').classList.remove('visible');
    
    document.getElementById('latitude').textContent = lat.toFixed(6);
    document.getElementById('longitude').textContent = lng.toFixed(6);
    document.getElementById('accuracy').textContent = 'Manual';
    
    reverseGeocode(lat, lng);
    
    if (userMarker) {
        map.removeLayer(userMarker);
    }
    
    userMarker = L.marker([lat, lng], {
        icon: createPulsingIcon()
    }).addTo(map);
    
    updateMunicipalityList();
    
    showToast('success', 'Location Set', 'Your location has been set manually.');
}

function createPulsingIcon() {
    return L.divIcon({
        className: 'pulsing-marker',
        html: `
            <div class="marker-pulse"></div>
            <div class="marker-core"></div>
        `,
        iconSize: [30, 30],
        iconAnchor: [15, 15]
    });
}

const markerStyle = document.createElement('style');
markerStyle.textContent = `
    .pulsing-marker {
        position: relative;
    }
    .marker-core {
        width: 16px;
        height: 16px;
        background: linear-gradient(135deg, #00ff88, #00d4ff);
        border-radius: 50%;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        box-shadow: 0 0 10px #00ff88;
    }
    .marker-pulse {
        width: 30px;
        height: 30px;
        border: 3px solid #00ff88;
        border-radius: 50%;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        animation: markerPulse 2s ease-out infinite;
    }
    @keyframes markerPulse {
        0% { transform: translate(-50%, -50%) scale(0.5); opacity: 1; }
        100% { transform: translate(-50%, -50%) scale(2); opacity: 0; }
    }
`;
document.head.appendChild(markerStyle);

async function reverseGeocode(lat, lng) {
    try {
        const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`);
        const data = await response.json();
        document.getElementById('address').textContent = data.display_name || 'Address not found';
    } catch (error) {
        document.getElementById('address').textContent = 'Unable to fetch address';
    }
}

function initTabs() {
    document.querySelectorAll('.nav-tab').forEach(tab => {
        tab.addEventListener('click', function() {
            const tabId = this.dataset.tab;
            
            document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            
            document.getElementById(`${tabId}-tab`).classList.add('active');
        });
    });
}

function initThemeToggle() {
    const toggle = document.getElementById('themeToggle');
    toggle.addEventListener('click', function() {
        document.body.classList.toggle('dark-theme');
        document.body.classList.toggle('light-theme');
    });
}

function initUploadZones() {
    setupUploadZone('wasteUploadZone', 'wasteImageInput', 'wastePreview', 'wastePreviewImg', 'wasteImageMeta', 'removeWasteImage', analyzeWasteImage);
    setupUploadZone('hygieneUploadZone', 'hygieneImageInput', 'hygienePreview', 'hygienePreviewImg', 'hygieneImageMeta', 'removeHygieneImage', analyzeHygieneImage);
}

function setupUploadZone(zoneId, inputId, previewId, imgId, metaId, removeBtnId, analyzeCallback) {
    const zone = document.getElementById(zoneId);
    const input = document.getElementById(inputId);
    const preview = document.getElementById(previewId);
    const img = document.getElementById(imgId);
    const meta = document.getElementById(metaId);
    const removeBtn = document.getElementById(removeBtnId);
    
    zone.addEventListener('click', () => input.click());
    
    zone.addEventListener('dragover', (e) => {
        e.preventDefault();
        zone.classList.add('dragover');
    });
    
    zone.addEventListener('dragleave', () => {
        zone.classList.remove('dragover');
    });
    
    zone.addEventListener('drop', (e) => {
        e.preventDefault();
        zone.classList.remove('dragover');
        const file = e.dataTransfer.files[0];
        if (file && file.type.startsWith('image/')) {
            handleImageUpload(file, zone, preview, img, meta, analyzeCallback);
        }
    });
    
    input.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            handleImageUpload(file, zone, preview, img, meta, analyzeCallback);
        }
    });
    
    removeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        zone.classList.remove('hidden');
        preview.classList.add('hidden');
        input.value = '';
        resetAnalysis(zoneId.includes('waste') ? 'waste' : 'hygiene');
    });
}

function handleImageUpload(file, zone, preview, img, meta, analyzeCallback) {
    const reader = new FileReader();
    reader.onload = (e) => {
        img.src = e.target.result;
        const tempImg = new Image();
        tempImg.onload = function() {
            const sizeMB = (file.size / (1024 * 1024)).toFixed(2);
            meta.innerHTML = `
                <strong>${file.name}</strong><br>
                Size: ${sizeMB} MB | Resolution: ${this.width} x ${this.height}
            `;
        };
        tempImg.src = e.target.result;
        
        zone.classList.add('hidden');
        preview.classList.remove('hidden');
        
        setTimeout(() => analyzeCallback(), 500);
    };
    reader.readAsDataURL(file);
}

function resetAnalysis(type) {
    if (type === 'waste') {
        document.getElementById('wasteAiContent').classList.remove('hidden');
        document.getElementById('wasteAiResults').classList.add('hidden');
    } else {
        document.getElementById('hygieneAiContent').classList.remove('hidden');
        document.getElementById('hygieneAiResults').classList.add('hidden');
        document.getElementById('hygieneBreakdown').classList.add('hidden');
        document.getElementById('breakdownPlaceholder').classList.remove('hidden');
        document.getElementById('lowScoreAlert').classList.add('hidden');
    }
}

function analyzeWasteImage() {
    document.getElementById('wasteAiContent').classList.add('hidden');
    document.getElementById('wasteAiResults').classList.remove('hidden');
    
    const severity = Math.floor(Math.random() * 100);
    const confidence = Math.floor(Math.random() * 30) + 70;
    
    animateScore('wasteSeverityScore', severity);
    animateProgress('wasteSeverityProgress', severity);
    
    document.getElementById('wasteConfidenceFill').style.width = `${confidence}%`;
    document.getElementById('wasteConfidenceValue').textContent = `${confidence}%`;
    
    const tags = getRandomTags();
    const tagsContainer = document.getElementById('wasteTags');
    tagsContainer.innerHTML = tags.map((tag, i) => 
        `<span class="waste-tag" style="animation-delay: ${i * 0.1}s">${tag}</span>`
    ).join('');
}

function analyzeHygieneImage() {
    document.getElementById('hygieneAiContent').classList.add('hidden');
    document.getElementById('hygieneAiResults').classList.remove('hidden');
    document.getElementById('hygieneBreakdown').classList.remove('hidden');
    document.getElementById('breakdownPlaceholder').classList.add('hidden');
    
    const score = Math.floor(Math.random() * 100);
    
    animateScore('hygieneScore', score);
    animateProgress('hygieneScoreProgress', score);
    
    const ratingBadge = document.querySelector('#hygieneRating .rating-badge');
    ratingBadge.className = 'rating-badge';
    
    if (score >= 90) {
        ratingBadge.textContent = 'Excellent Hygiene';
        ratingBadge.classList.add('excellent');
    } else if (score >= 70) {
        ratingBadge.textContent = 'Good Hygiene';
        ratingBadge.classList.add('good');
    } else if (score >= 40) {
        ratingBadge.textContent = 'Needs Cleaning';
        ratingBadge.classList.add('needs-cleaning');
    } else {
        ratingBadge.textContent = 'Critical Poor Hygiene';
        ratingBadge.classList.add('critical');
    }
    
    const metrics = {
        floor: Math.floor(Math.random() * 100),
        seat: Math.floor(Math.random() * 100),
        wall: Math.floor(Math.random() * 100),
        odor: Math.floor(Math.random() * 100),
        spill: Math.floor(Math.random() * 100)
    };
    
    Object.entries(metrics).forEach(([key, value]) => {
        setTimeout(() => {
            document.getElementById(`${key}Bar`).style.width = `${value}%`;
            document.getElementById(`${key}Value`).textContent = `${value}%`;
        }, 200);
    });
    
    if (score < 50) {
        document.getElementById('lowScoreAlert').classList.remove('hidden');
    } else {
        document.getElementById('lowScoreAlert').classList.add('hidden');
    }
}

function animateScore(elementId, targetValue) {
    const element = document.getElementById(elementId);
    let current = 0;
    const increment = targetValue / 50;
    const interval = setInterval(() => {
        current += increment;
        if (current >= targetValue) {
            current = targetValue;
            clearInterval(interval);
        }
        element.textContent = Math.floor(current);
    }, 20);
}

function animateProgress(elementId, value) {
    const element = document.getElementById(elementId);
    const circumference = 339.292;
    const offset = circumference - (value / 100) * circumference;
    setTimeout(() => {
        element.style.strokeDashoffset = offset;
    }, 100);
}

function getRandomTags() {
    const shuffled = [...wasteTypes].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, Math.floor(Math.random() * 3) + 2);
}

function initCategoryButtons() {
    document.querySelectorAll('.category-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.category-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            selectedCategory = this.dataset.category;
        });
    });
}

function initChatbot() {
    const toggle = document.getElementById('chatbotToggle');
    const window = document.getElementById('chatbotWindow');
    const input = document.getElementById('chatInput');
    const sendBtn = document.getElementById('sendMessage');
    
    toggle.addEventListener('click', () => {
        toggle.classList.toggle('active');
        window.classList.toggle('active');
    });
    
    sendBtn.addEventListener('click', sendChatMessage);
    input.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendChatMessage();
    });
}

function sendChatMessage() {
    const input = document.getElementById('chatInput');
    const message = input.value.trim();
    if (!message) return;
    
    addChatMessage(message, 'user');
    input.value = '';
    
    showTypingIndicator();
    
    setTimeout(() => {
        removeTypingIndicator();
        const response = getChatbotResponse(message);
        addChatMessage(response, 'bot');
    }, 1000 + Math.random() * 1000);
}

function addChatMessage(text, type) {
    const container = document.getElementById('chatbotMessages');
    const div = document.createElement('div');
    div.className = `message ${type}-message`;
    div.innerHTML = `<div class="message-content">${text}</div>`;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
}

function showTypingIndicator() {
    const container = document.getElementById('chatbotMessages');
    const div = document.createElement('div');
    div.className = 'typing-indicator';
    div.id = 'typingIndicator';
    div.innerHTML = `
        <div class="typing-dot"></div>
        <div class="typing-dot"></div>
        <div class="typing-dot"></div>
    `;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
}

function removeTypingIndicator() {
    const indicator = document.getElementById('typingIndicator');
    if (indicator) indicator.remove();
}

function getChatbotResponse(message) {
    const msg = message.toLowerCase();
    
    if (msg.includes('report') || msg.includes('waste')) {
        return "To report waste, go to the 'Waste Report' tab, upload an image of the waste, select a category, and click 'Submit Report'. Our AI will analyze the severity automatically!";
    }
    if (msg.includes('hygiene') || msg.includes('toilet') || msg.includes('bathroom')) {
        return "For toilet hygiene scoring, visit the 'Toilet Hygiene' tab. Upload a photo and our AI will generate a cleanliness score with detailed breakdown of floor, seat, walls, and more.";
    }
    if (msg.includes('municipality') || msg.includes('contact')) {
        return "You can find nearby municipalities in the 'Municipality' tab. We calculate the nearest ones based on your location and provide contact details including email and phone.";
    }
    if (msg.includes('dashboard') || msg.includes('stats')) {
        return "The Dashboard shows overall statistics including total reports, cleanup success rates, average severity scores, and weekly trends. Check it out in the 'Dashboard' tab!";
    }
    if (msg.includes('location') || msg.includes('gps')) {
        return "We use your device's GPS to detect your location automatically. If GPS fails, you can click anywhere on the map to set your location manually.";
    }
    if (msg.includes('hello') || msg.includes('hi') || msg.includes('hey')) {
        return "Hello! Welcome to SmartSanitizeAI. How can I assist you today? I can help with waste reporting, hygiene scoring, finding municipalities, or explaining app features.";
    }
    if (msg.includes('thank')) {
        return "You're welcome! If you have any more questions, feel free to ask. Together we're building cleaner cities!";
    }
    
    return "I can help you with: reporting waste, toilet hygiene scoring, finding municipalities, or understanding the dashboard. What would you like to know more about?";
}

function initDashboard() {
    animateDashboardStats();
    
    setTimeout(() => {
        drawWeeklyChart();
        drawTrendsChart();
    }, 500);
}

function animateDashboardStats() {
    const stats = {
        totalReports: Math.floor(Math.random() * 500) + 200,
        cleanupRate: Math.floor(Math.random() * 30) + 70,
        avgSeverity: Math.floor(Math.random() * 40) + 30,
        avgHygiene: Math.floor(Math.random() * 30) + 60
    };
    
    animateCounter('totalReports', stats.totalReports);
    animateCounter('cleanupRate', stats.cleanupRate, '%');
    animateCounter('avgSeverity', stats.avgSeverity);
    animateCounter('avgHygiene', stats.avgHygiene);
}

function animateCounter(elementId, target, suffix = '') {
    const element = document.getElementById(elementId);
    let current = 0;
    const increment = target / 60;
    const interval = setInterval(() => {
        current += increment;
        if (current >= target) {
            current = target;
            clearInterval(interval);
        }
        element.textContent = Math.floor(current) + suffix;
    }, 16);
}

function drawWeeklyChart() {
    const canvas = document.getElementById('weeklyChart');
    const ctx = canvas.getContext('2d');
    
    canvas.width = canvas.offsetWidth * 2;
    canvas.height = canvas.offsetHeight * 2;
    ctx.scale(2, 2);
    
    const width = canvas.offsetWidth;
    const height = canvas.offsetHeight;
    const padding = 40;
    const chartWidth = width - padding * 2;
    const chartHeight = height - padding * 2;
    
    const data = Array.from({ length: 7 }, () => Math.floor(Math.random() * 80) + 20);
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const maxValue = Math.max(...data);
    const barWidth = chartWidth / data.length - 10;
    
    ctx.fillStyle = getComputedStyle(document.body).getPropertyValue('--text-secondary');
    ctx.font = '11px Poppins';
    ctx.textAlign = 'center';
    
    data.forEach((value, i) => {
        const x = padding + (i * (chartWidth / data.length)) + barWidth / 2;
        const barHeight = (value / maxValue) * chartHeight;
        const y = height - padding - barHeight;
        
        const gradient = ctx.createLinearGradient(x, y, x, height - padding);
        gradient.addColorStop(0, '#00ff88');
        gradient.addColorStop(1, '#00d4ff');
        
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.roundRect(x - barWidth / 2, y, barWidth, barHeight, 5);
        ctx.fill();
        
        ctx.fillStyle = getComputedStyle(document.body).getPropertyValue('--text-secondary');
        ctx.fillText(days[i], x, height - padding + 20);
        ctx.fillText(value, x, y - 10);
    });
}

function drawTrendsChart() {
    const canvas = document.getElementById('trendsChart');
    const ctx = canvas.getContext('2d');
    
    canvas.width = canvas.offsetWidth * 2;
    canvas.height = canvas.offsetHeight * 2;
    ctx.scale(2, 2);
    
    const width = canvas.offsetWidth;
    const height = canvas.offsetHeight;
    const padding = 40;
    const chartWidth = width - padding * 2;
    const chartHeight = height - padding * 2;
    
    const data = Array.from({ length: 10 }, () => Math.floor(Math.random() * 60) + 20);
    const maxValue = Math.max(...data);
    
    const gradient = ctx.createLinearGradient(0, padding, 0, height - padding);
    gradient.addColorStop(0, 'rgba(168, 85, 247, 0.3)');
    gradient.addColorStop(1, 'rgba(168, 85, 247, 0)');
    
    ctx.beginPath();
    ctx.moveTo(padding, height - padding);
    
    data.forEach((value, i) => {
        const x = padding + (i * (chartWidth / (data.length - 1)));
        const y = height - padding - (value / maxValue) * chartHeight;
        ctx.lineTo(x, y);
    });
    
    ctx.lineTo(padding + chartWidth, height - padding);
    ctx.closePath();
    ctx.fillStyle = gradient;
    ctx.fill();
    
    ctx.beginPath();
    data.forEach((value, i) => {
        const x = padding + (i * (chartWidth / (data.length - 1)));
        const y = height - padding - (value / maxValue) * chartHeight;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
    });
    
    ctx.strokeStyle = '#a855f7';
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.stroke();
    
    data.forEach((value, i) => {
        const x = padding + (i * (chartWidth / (data.length - 1)));
        const y = height - padding - (value / maxValue) * chartHeight;
        
        ctx.beginPath();
        ctx.arc(x, y, 5, 0, Math.PI * 2);
        ctx.fillStyle = '#a855f7';
        ctx.fill();
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = 2;
        ctx.stroke();
    });
}

function haversineDistance(lat1, lon1, lat2, lon2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
}

function updateMunicipalityList() {
    if (!currentPosition) return;
    
    const listContainer = document.getElementById('municipalityList');
    
    const municipalitiesWithDistance = municipalityData.map(m => ({
        ...m,
        distance: haversineDistance(currentPosition.lat, currentPosition.lng, m.lat, m.lng)
    })).sort((a, b) => a.distance - b.distance);
    
    listContainer.innerHTML = municipalitiesWithDistance.map((m, i) => `
        <div class="municipality-item ${i === 0 ? 'nearest' : ''}" data-id="${m.id}">
            <div class="muni-icon">&#127970;</div>
            <div class="muni-info">
                <div class="muni-name">${m.name}</div>
                <div class="muni-distance">${m.distance.toFixed(2)} km away</div>
            </div>
            ${i === 0 ? '<span class="nearest-badge">NEAREST</span>' : ''}
        </div>
    `).join('');
    
    document.querySelectorAll('.municipality-item').forEach(item => {
        item.addEventListener('click', function() {
            const id = parseInt(this.dataset.id);
            selectMunicipality(id);
            
            document.querySelectorAll('.municipality-item').forEach(i => i.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

function selectMunicipality(id) {
    const municipality = municipalityData.find(m => m.id === id);
    if (!municipality) return;
    
    selectedMunicipality = municipality;
    
    const detailsContainer = document.getElementById('municipalityDetails');
    detailsContainer.innerHTML = `
        <div class="detail-content">
            <div class="detail-header">
                <div class="muni-icon">&#127970;</div>
                <div>
                    <h4>${municipality.name}</h4>
                    <span style="color: var(--accent-green);">${haversineDistance(currentPosition.lat, currentPosition.lng, municipality.lat, municipality.lng).toFixed(2)} km away</span>
                </div>
            </div>
            <div class="detail-row">
                <span class="icon">&#128231;</span>
                <span class="label">Email</span>
                <span class="value"><a href="mailto:${municipality.email}">${municipality.email}</a></span>
            </div>
            <div class="detail-row">
                <span class="icon">&#128222;</span>
                <span class="label">Phone</span>
                <span class="value"><a href="tel:${municipality.phone}">${municipality.phone}</a></span>
            </div>
            <div class="detail-row">
                <span class="icon">&#128205;</span>
                <span class="label">Location</span>
                <span class="value">${municipality.lat.toFixed(4)}, ${municipality.lng.toFixed(4)}</span>
            </div>
            <button class="btn-primary route-btn" onclick="drawRoute(${municipality.lat}, ${municipality.lng})">
                <span>&#128663;</span> Show Route on Map
            </button>
        </div>
    `;
}

function drawRoute(destLat, destLng) {
    if (!currentPosition) {
        showToast('error', 'Location Required', 'Please set your location first.');
        return;
    }
    
    if (routeLine) {
        map.removeLayer(routeLine);
    }
    
    routeLine = L.polyline([
        [currentPosition.lat, currentPosition.lng],
        [destLat, destLng]
    ], {
        color: '#00ff88',
        weight: 4,
        opacity: 0.8,
        dashArray: '10, 10'
    }).addTo(map);
    
    const destMarker = L.marker([destLat, destLng], {
        icon: L.divIcon({
            className: 'dest-marker',
            html: '<div style="width: 20px; height: 20px; background: #a855f7; border-radius: 50%; border: 3px solid white; box-shadow: 0 0 10px #a855f7;"></div>',
            iconSize: [20, 20],
            iconAnchor: [10, 10]
        })
    }).addTo(map);
    
    const bounds = L.latLngBounds([
        [currentPosition.lat, currentPosition.lng],
        [destLat, destLng]
    ]);
    map.fitBounds(bounds, { padding: [50, 50] });
    
    document.querySelector('.nav-tab[data-tab="waste"]').click();
    
    showToast('success', 'Route Displayed', 'The route to municipality has been shown on the map.');
}

function initEventListeners() {
    document.getElementById('recenterBtn').addEventListener('click', () => {
        if (currentPosition) {
            map.setView([currentPosition.lat, currentPosition.lng], 15);
        } else {
            showToast('warning', 'No Location', 'Location not available. Click on map to set manually.');
        }
    });
    
    document.getElementById('submitWasteReport').addEventListener('click', () => {
        if (!currentPosition) {
            showToast('error', 'Location Required', 'Please set your location before submitting.');
            return;
        }
        
        const preview = document.getElementById('wastePreview');
        if (preview.classList.contains('hidden')) {
            showToast('error', 'Image Required', 'Please upload an image of the waste.');
            return;
        }
        
        if (!selectedCategory) {
            showToast('warning', 'Category Required', 'Please select a waste category.');
            return;
        }
        
        showToast('success', 'Report Submitted', 'Your waste report has been submitted successfully. Thank you!');
    });
    
    document.getElementById('sendHygieneReport').addEventListener('click', () => {
        showToast('success', 'Alert Sent', 'Cleaning alert has been sent to the nearest municipality.');
        document.getElementById('lowScoreAlert').classList.add('hidden');
    });
}

function showToast(type, title, message) {
    const container = document.getElementById('toastContainer');
    
    const icons = {
        success: '&#9989;',
        error: '&#10060;',
        warning: '&#9888;&#65039;'
    };
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <span class="toast-icon">${icons[type]}</span>
        <div class="toast-content">
            <div class="toast-title">${title}</div>
            <div class="toast-message">${message}</div>
        </div>
        <button class="toast-close">&times;</button>
    `;
    
    container.appendChild(toast);
    
    toast.querySelector('.toast-close').addEventListener('click', () => {
        toast.remove();
    });
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

const svgDefs = `
<svg width="0" height="0" style="position: absolute;">
    <defs>
        <linearGradient id="severityGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style="stop-color:#ff4444"/>
            <stop offset="50%" style="stop-color:#ff8800"/>
            <stop offset="100%" style="stop-color:#00ff88"/>
        </linearGradient>
        <linearGradient id="hygieneGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style="stop-color:#00ff88"/>
            <stop offset="100%" style="stop-color:#00d4ff"/>
        </linearGradient>
    </defs>
</svg>
`;
document.body.insertAdjacentHTML('afterbegin', svgDefs);
